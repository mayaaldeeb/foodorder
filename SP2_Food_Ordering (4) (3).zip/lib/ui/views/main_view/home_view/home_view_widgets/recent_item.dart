import 'package:flutter/material.dart';

class RecentItem extends StatelessWidget {
  const RecentItem({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Row(
      children: [],
    );
  }
}
