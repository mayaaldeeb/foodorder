enum NotificationType { SUBSECRIPTION, CHANGECOLOR }
