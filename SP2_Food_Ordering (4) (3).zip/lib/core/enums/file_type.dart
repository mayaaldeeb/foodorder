enum FileTypeEnum { CAMERA, GALLERY, FILE }
