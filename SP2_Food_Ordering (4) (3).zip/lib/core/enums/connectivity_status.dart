enum ConnectivityStatus {
  ONLINE,
  OFFLINE,
}
