enum DataType {
  INT,
  BOOL,
  STRING,
  DOUBLE,
  LISTSTRING,
}
