enum BottomNavigationEnum {
  MENU,
  OFFERS,
  HOME,
  PROFILE,
  MORE,
}
