enum OperationType {
  NONE,
  CATEGORY,
  MEAL,
}
