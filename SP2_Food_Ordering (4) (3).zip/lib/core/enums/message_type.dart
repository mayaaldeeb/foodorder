enum MessageType {
  INFO,
  WARNING,
  REJECTED,
  SUCCSESS,
}
