enum RequestType {
  GET,
  POST,
  PUT,
  DELETE,
}

