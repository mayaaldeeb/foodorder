class ARLanguage {
  static Map<String, String> get map => {"key_login": "تسجيل الدخول"};
}
