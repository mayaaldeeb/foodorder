class ENLanguage {
  static Map<String, String> get map => {
        "key_login": "Login",
        "login_details": "Add your details to login",
      };
}
