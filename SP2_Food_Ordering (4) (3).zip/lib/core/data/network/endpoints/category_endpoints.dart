import 'package:food_ordering_sp2/core/data/network/network_config.dart';

class CategoryEndpoints {
  static String getall = NetworkConfig.getFullApiUrl('category/getall');
}
