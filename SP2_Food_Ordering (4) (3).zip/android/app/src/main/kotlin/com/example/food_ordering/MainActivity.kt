package com.example.food_ordering

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
